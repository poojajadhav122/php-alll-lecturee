<script> 
	window.location.href="views/login.php"

</script>


<?php 
	//header("location:views/index.php");

?>