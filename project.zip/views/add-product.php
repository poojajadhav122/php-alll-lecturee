<?php
	/**/ 
	session_start();
	// print_r($_SESSION);
	if(!isset($_SESSION['project_name'])){
		header("location:index.php");
	}
	/**/
	require_once 'header.php';
?>
<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h2>Add Product</h2>

						<form id="product_form">

							<input type="text" name="pro_name" placeholder="Mens Formal Wear" />

							<input type="text" name="pro_price" placeholder="2400" />

							<input type="text" name="pro_discount" placeholder="20 in %" />

							<select name="pro_caid">
								<option value="">Please Select Category</option>
								<?php
								$res = $obj->show_categories();
								// pre($res);
								if(is_array($res)){
									foreach($res as $key=>$val){
										$id=$val['ca_id'];
			echo "<option value='$id'>".$val['ca_name']."</option>";
									}
								}
								?>
							</select>
							<br><br>
							<select name="pro_brid">
								<option value="">Please Select Brand</option>
								<?php
								$res = $obj->show_brands();
								// pre($res);
								if(is_array($res)){
									foreach($res as $key=>$val){
										$id = $val['br_id'];
										echo "<option value='$id'>".$val['br_name']."</option>";
									}
								}
								?>
							</select>
							<br><br>

							<input type="file" name="pro_path" />

							<textarea name="pro_desc" placeholder="Product Description"></textarea>

							<button type="button" class="btn btn-default btn-product"> Add product</button>
							
						</form>
						<div class="msg_product"></div>

					</div><!--/login form-->
				</div>
				
			</div>
		</div>
	</section><!--/form-->
		
<?php
	require_once 'footer.php';
?>