<?php
	session_start();
	// print_r($_SESSION);
	if(!isset($_SESSION['project_name'])){
		header("location:index.php");
	}
	require_once 'header.php';
?>
	
	<div class="container">

	<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h2>Update password!</h2>
						<form id="update_form">
							<input type="password" name="cpass" placeholder="Enter current Password" />
							<input type="password" name="npass" placeholder="Enter new Password" />
							<input type="password" name="cnpass" placeholder="Enter Confirm  new Password" />
							<button type="button" class="btn btn-default btn-update">Update</button>
						</form>
						<div class="msg_update"></div>
					</div><!--/sign up form-->
				</div>
</div>
<?php
	require_once 'footer.php';
?>