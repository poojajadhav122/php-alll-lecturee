<script>
	// window.location.href="views/index.php"
</script>	

<?php
	header("location:views/index.php");
?>