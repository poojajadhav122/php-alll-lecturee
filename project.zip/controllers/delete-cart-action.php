<?php
	// print_r($_POST);
	$proid = $_POST['x'];
	// echo $proid;
	// 4
	$cartdata = $_COOKIE['cookie_product_id'];
	// echo $cartdata;
	// 5,4,4,6
	$arr = explode(",",$cartdata);
	// print_r($arr);
	//arr(5,4,4,6)
	foreach($arr as $key=>$val){
		// echo $val;
		// echo $key;
		if($val==$proid){
			// echo $key;
			unset($arr[$key]);
		}	
	}
	// print_r($arr);
	////arr(5,6)
	$newproduct = implode(",",$arr);
	// echo $newpro;
	//5,6
	setcookie("cookie_product_id",$newproduct,time() + 36000,"/");

	$ans = explode(",",$newproduct);
	// print_r($ans);
	$result = array_unique($ans);
	// print_r($result);
	echo count($result);
?>