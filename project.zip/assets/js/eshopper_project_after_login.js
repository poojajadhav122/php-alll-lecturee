$(document).ready(function(){
	// alert("TEST")
	$(".btn-update").click(function(){
		records = $("#update_form").serialize();
		// alert(records)
		$.post("../controllers/password-action.php" , records).success(function(res){
			// console.log(res);
			$(".msg_update").html(res);
		})
	})

	/////////
	$(".btn-product").click(function(){
		//create an object of given form 
		formobj = document.getElementById("product_form");
		// alert(formobj);
		//create an object of form data
		dataobj = new FormData(formobj);
		// alert(dataobj);		
		$.ajax({
			type:"post",
			data:dataobj,
			url:"../controllers/product-action.php",
			contentType:false, // text/plain , enctype
			processData:false,
			success:function(res){
				$(".msg_product").html(res);
			},
			error:function(errmsg){
				console.log(errmsg)
			}
		});

	})

	//////////////
})